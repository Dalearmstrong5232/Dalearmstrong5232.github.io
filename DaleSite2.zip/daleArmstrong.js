$(document).ready(function() {
 $(".links").hide();
  $("#expand").click(function() {
  	$(".links").slideDown(2000);
  })

  
 
});